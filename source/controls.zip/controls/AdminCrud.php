<!-- Toda estrutura de Crud do Admin -->
<?php

  if(isset($_POST['register-company'])){
    // Pegar todos os dados dos usuários

  }
